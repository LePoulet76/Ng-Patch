package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseBankDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseBankDataPacket this$0;

    EnterpriseBankDataPacket$1(EnterpriseBankDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
