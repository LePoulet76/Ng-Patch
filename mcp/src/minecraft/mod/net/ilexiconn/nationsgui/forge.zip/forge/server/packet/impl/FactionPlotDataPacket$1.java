package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionPlotDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionPlotDataPacket this$0;

    FactionPlotDataPacket$1(FactionPlotDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
