package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.TreeMap;

class FactionMembersDataPacket$1 extends TypeToken<TreeMap<String, Object>>
{
    final FactionMembersDataPacket this$0;

    FactionMembersDataPacket$1(FactionMembersDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
