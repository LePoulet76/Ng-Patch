package net.ilexiconn.nationsgui.forge.server.container;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

class IncubatorContainer$2 extends Slot
{
    final IncubatorContainer this$0;

    IncubatorContainer$2(IncubatorContainer this$0, IInventory x0, int x1, int x2, int x3)
    {
        super(x0, x1, x2, x3);
        this.this$0 = this$0;
    }

    /**
     * Check if the stack is a valid item for this slot. Always true beside for the armor slots.
     */
    public boolean isItemValid(ItemStack itemStack)
    {
        return itemStack.getItem().itemID == Item.monsterPlacer.itemID;
    }
}
