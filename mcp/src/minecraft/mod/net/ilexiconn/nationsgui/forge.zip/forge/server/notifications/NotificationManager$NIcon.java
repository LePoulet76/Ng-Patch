package net.ilexiconn.nationsgui.forge.server.notifications;

public enum NotificationManager$NIcon
{
    CALENDAR_ADD,
    PEOPLE_BLACK,
    HAND_PLUS,
    TARGET_BLACK,
    LOCK_GREY,
    FLAG,
    ISLAND,
    ENTER,
    TICKET,
    HAND_PLUS_GREY,
    CHAT_GREY,
    HAND_SHAKE,
    CLOUD_GREY,
    SKULL,
    CALENDAR_BLUE,
    MEDAL_STAR_BLACK,
    MEDAL_CHECK_BLACK,
    STAR_BLACK,
    QUESTION,
    EXCLAMATION,
    VOTE,
    CHECK,
    THUMBS_UP,
    ALARM,
    LEAVE;
}
