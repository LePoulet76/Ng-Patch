package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseCreateDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseCreateDataPacket this$0;

    EnterpriseCreateDataPacket$1(EnterpriseCreateDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
