package net.minecraft.client.audio;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
class ScheduledSound
{
    String field_92069_a;
    float field_92067_b;
    float field_92068_c;
    float field_92065_d;
    float field_92066_e;
    float field_92063_f;
    int field_92064_g;

    public ScheduledSound(String par1Str, float par2, float par3, float par4, float par5, float par6, int par7)
    {
        this.field_92069_a = par1Str;
        this.field_92067_b = par2;
        this.field_92068_c = par3;
        this.field_92065_d = par4;
        this.field_92066_e = par5;
        this.field_92063_f = par6;
        this.field_92064_g = par7;
    }
}
