package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseTraderDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseTraderDataPacket this$0;

    EnterpriseTraderDataPacket$1(EnterpriseTraderDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
