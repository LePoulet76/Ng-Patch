package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class CosmeticDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final CosmeticDataPacket this$0;

    CosmeticDataPacket$1(CosmeticDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
