package acs.proxy;

import net.ilexiconn.nationsgui.forge.client.data.ClientConfig;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {
    public static final ClientConfig clientConfig = new ClientConfig();
    @Override
    public void initRenderers() {
        // Init GUI or other client-side stuff if needed
    }

    @Override
    public void playNotificationSound() {
        Minecraft.getMinecraft().sndManager.playSoundFX("random.pop", 1.0F, 1.0F);
    }

    @Override
    public boolean isTimestampEnabled() {
        return clientConfig != null && clientConfig.enableTimestamp;
    }
    @Override
    public boolean isTagEnabled() {
        return clientConfig != null && clientConfig.enableTag;
    }
}
