package net.ilexiconn.nationsgui.forge.server.event;

class PotionEffectEvent$1
{
}
