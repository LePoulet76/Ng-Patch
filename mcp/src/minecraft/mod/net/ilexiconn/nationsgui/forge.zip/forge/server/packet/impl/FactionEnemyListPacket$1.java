package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionEnemyListPacket$1 extends TypeToken<ArrayList<HashMap<String, Object>>>
{
    final FactionEnemyListPacket this$0;

    FactionEnemyListPacket$1(FactionEnemyListPacket this$0)
    {
        this.this$0 = this$0;
    }
}
