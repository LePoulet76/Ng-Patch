package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionSkillsCountriesLeaderboardDataPacket$3 extends TypeToken<HashMap<String, Double>>
{
    final FactionSkillsCountriesLeaderboardDataPacket this$0;

    FactionSkillsCountriesLeaderboardDataPacket$3(FactionSkillsCountriesLeaderboardDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
