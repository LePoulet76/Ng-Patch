package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionChestSaveDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionChestSaveDataPacket this$0;

    FactionChestSaveDataPacket$1(FactionChestSaveDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
