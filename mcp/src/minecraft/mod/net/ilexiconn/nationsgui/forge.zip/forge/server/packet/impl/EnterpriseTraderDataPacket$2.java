package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;

class EnterpriseTraderDataPacket$2 extends TypeToken<LinkedHashMap<Date, Double>>
{
    final EnterpriseTraderDataPacket this$0;

    EnterpriseTraderDataPacket$2(EnterpriseTraderDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
