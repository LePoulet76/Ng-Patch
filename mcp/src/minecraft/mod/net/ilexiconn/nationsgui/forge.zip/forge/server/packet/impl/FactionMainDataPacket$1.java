package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionMainDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionMainDataPacket this$0;

    FactionMainDataPacket$1(FactionMainDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
