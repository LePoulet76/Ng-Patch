package net.ilexiconn.nationsgui.forge.server.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * Stub serveur pour RadioBlock, sans logique client.
 */
public class RadioBlock extends Block {
    public RadioBlock() {
        super(Material.rock);
    }
}
