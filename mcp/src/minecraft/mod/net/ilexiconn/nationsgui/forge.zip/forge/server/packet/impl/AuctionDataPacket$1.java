package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.common.reflect.TypeToken;
import java.util.List;
import net.ilexiconn.nationsgui.forge.client.data.Auction;

class AuctionDataPacket$1 extends TypeToken<List<Auction>>
{
    final AuctionDataPacket this$0;

    AuctionDataPacket$1(AuctionDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
