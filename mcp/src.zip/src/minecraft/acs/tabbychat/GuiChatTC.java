/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cpw.mods.fml.common.network.PacketDispatcher
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.ChatClickData
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiConfirmOpenLink
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.entity.RenderItem
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.Packet203AutoComplete
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package acs.tabbychat;

import acs.tabbychat.ChatButton;
import acs.tabbychat.ChatChannel;
import acs.tabbychat.ChatScrollBar;
import acs.tabbychat.TabbyChat;
import acs.tabbychat.TabbyChatUtils;
import cpw.mods.fml.common.network.PacketDispatcher;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.ilexiconn.nationsgui.forge.NationsGUI;
import net.ilexiconn.nationsgui.forge.client.ClientData;
import net.ilexiconn.nationsgui.forge.client.ClientEventHandler;
import net.ilexiconn.nationsgui.forge.client.ClientProxy;
import net.ilexiconn.nationsgui.forge.client.chat.ChatClickCountryData;
import net.ilexiconn.nationsgui.forge.client.chat.ChatClickProfilData;
import net.ilexiconn.nationsgui.forge.client.data.Objective;
import net.ilexiconn.nationsgui.forge.client.gui.GuiScrollBar;
import net.ilexiconn.nationsgui.forge.client.gui.faction.FactionGUI;
import net.ilexiconn.nationsgui.forge.client.gui.faction.ProfilGui;
import net.ilexiconn.nationsgui.forge.client.gui.island.IslandListGui;
import net.ilexiconn.nationsgui.forge.client.gui.island.IslandMainGui;
import net.ilexiconn.nationsgui.forge.client.gui.modern.ModernGui;
import net.ilexiconn.nationsgui.forge.client.util.GUIUtils;
import net.ilexiconn.nationsgui.forge.server.asm.NationsGUIClientHooks;
import net.ilexiconn.nationsgui.forge.server.packet.PacketRegistry;
import net.ilexiconn.nationsgui.forge.server.packet.impl.ChatTabSetChatPacket;
import net.ilexiconn.nationsgui.forge.server.packet.impl.ObjectivePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatClickData;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiConfirmOpenLink;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.Packet203AutoComplete;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class GuiChatTC
extends GuiChat {
    public String historyBuffer = "";
    public String defaultInputFieldText = "";
    public int sentHistoryCursor = -1;
    private boolean playerNamesFound = false;
    private boolean waitingOnPlayerNames = false;
    private int playerNameIndex = 0;
    private List foundPlayerNames = new ArrayList();
    private URI clickedURI = null;
    public GuiTextField inputField;
    public List<GuiTextField> inputList = new ArrayList<GuiTextField>(3);
    public ChatScrollBar scrollBar;
    public GuiButton selectedButton = null;
    public int eventButton = 0;
    public long lastMouseEvent = 0L;
    public int field_92018_d = 0;
    public float zLevel = 0.0f;
    public ScaledResolution sr;
    public static GuiChatTC me;
    public static final TabbyChat tc;
    private int heightModifier = 0;
    private boolean displayText = false;
    public static final int BOX_WIDTH = 400;
    public static final int BOX_HEIGHT = 250;
    private ScrollBar scrollBarObj;
    private List<String> lines = new ArrayList<String>();
    private RenderItem itemRenderer = new RenderItem();
    private HashMap<Integer, String> mappingButtonIdEmote = new HashMap();
    private HashMap<Integer, String> mappingButtonIdAnim = new HashMap();
    private boolean displayEmotesGui = false;

    public GuiChatTC() {
        this.mc = Minecraft.getMinecraft();
        this.fontRenderer = this.mc.fontRenderer;
        me = this;
        this.sr = new ScaledResolution(this.mc.gameSettings, this.mc.displayWidth, this.mc.displayHeight);
    }

    public GuiChatTC(String par1Str) {
        this.defaultInputFieldText = par1Str;
    }

    public void initGui() {
        Double offsetY;
        Keyboard.enableRepeatEvents((boolean)true);
        this.sr = new ScaledResolution(this.mc.gameSettings, this.mc.displayWidth, this.mc.displayHeight);
        this.buttonList.clear();
        this.mappingButtonIdEmote.clear();
        this.inputList.clear();
        this.width = this.sr.getScaledWidth();
        this.height = this.sr.getScaledHeight();
        tc.checkServer();
        if (tc.enabled()) {
            this.drawChatTabs();
            if (this.scrollBar == null) {
                this.scrollBar = new ChatScrollBar(this);
            }
            this.scrollBar.drawScrollBar();
        } else if (!Minecraft.getMinecraft().isSingleplayer()) {
            tc.updateButtonLocations();
            this.buttonList.add(GuiChatTC.tc.channelMap.get((Object)"Global").tab);
        }
        this.sentHistoryCursor = TabbyChat.gnc.getSentMessages().size();
        this.inputField = new GuiTextField(this.fontRenderer, 4, this.height - 12, this.width - 4, 12);
        this.inputField.setMaxStringLength(500);
        this.inputField.setEnableBackgroundDrawing(false);
        this.inputField.setFocused(true);
        this.inputField.setText(this.defaultInputFieldText);
        this.inputField.setCanLoseFocus(true);
        this.inputList.add(0, this.inputField);
        if (!tc.enabled()) {
            return;
        }
        for (int i = 1; i < 3; ++i) {
            GuiTextField placeholder = new GuiTextField(this.fontRenderer, 4, this.height - 12 * (i + 1), this.width, 12);
            placeholder.setMaxStringLength(500);
            placeholder.setEnableBackgroundDrawing(false);
            placeholder.setFocused(false);
            placeholder.setText("");
            placeholder.setCanLoseFocus(true);
            placeholder.setVisible(false);
            this.inputList.add(i, placeholder);
        }
        int y = 30;
        if (ClientProxy.serverType.equals("ng") && ClientProxy.clientConfig.displayObjectives && !Minecraft.getMinecraft().gameSettings.showDebugInfo) {
            if (!this.displayText) {
                if (!ClientData.objectives.isEmpty()) {
                    int btnIndex = 10;
                    for (Objective objective : ClientData.objectives) {
                        this.buttonList.add(new Button(btnIndex, 4, y, 112, 29));
                        y += 34;
                        ++btnIndex;
                    }
                }
                this.scrollBarObj = null;
            } else {
                this.heightModifier = ClientData.objectives.get(ClientData.currentObjectiveIndex).getItemStack() != null ? 10 : 0;
                this.scrollBarObj = new ScrollBar(this.width / 2 + 200 - 15, this.height / 2 - 125 + 30, 185);
                if (ClientData.objectives.get(ClientData.currentObjectiveIndex).getItemStack() == null) {
                    this.buttonList.add(new SimpleButton(3, this.width / 2 + 200 - 56, this.height / 2 + 125 - 25, 50, 15, "Ok"));
                } else {
                    this.buttonList.add(new SimpleButton(4, this.width / 2 + 200 - 56, this.height / 2 + 125 - 25, 50, 15, "Ok"));
                    this.buttonList.add(new SimpleButton(3, this.width / 2 + 200 - 56 - 105, this.height / 2 + 125 - 25, 100, 15, I18n.getString((String)"objectives.validate")));
                }
            }
        }
        this.buttonList.add(new EmoteOpenButton(5, this.width - 34, this.height - 14, 12, 12));
        int buttonIndex = 0;
        int emoteWidth = this.width - 131 + buttonIndex % 5 * 22;
        int emoteHeight = this.height - 134 + buttonIndex / 5 * 20;
        for (Map.Entry<String, String> pair : NationsGUI.EMOTES_SYMBOLS.entrySet()) {
            if (!NationsGUI.EMOTES_RESOURCES.containsKey(pair.getKey())) continue;
            this.buttonList.add(new EmoteButton(100 + buttonIndex, emoteWidth, emoteHeight, 22, 20, pair.getKey()));
            this.mappingButtonIdEmote.put(100 + buttonIndex, pair.getKey());
            emoteWidth = this.width - 131 + ++buttonIndex % 5 * 22;
            emoteHeight = this.height - 134 + buttonIndex / 5 * 20;
        }
        if (ClientData.currentIsland != null && ClientData.currentIsland.size() > 0) {
            offsetY = (double)this.height * 0.4 + 78.0;
            this.buttonList.add(new VoidButton(6, this.width - 120 + 13, offsetY.intValue(), 94, 15));
            this.buttonList.add(new VoidButton(7, this.width - 120 + 13, offsetY.intValue() + 20, 94, 15));
        } else if (!ClientData.currentJumpLocation.isEmpty()) {
            offsetY = (double)this.height * 0.4 + 80.0;
            this.buttonList.add(new VoidButton(6, this.width - 140, offsetY.intValue(), 140, 16));
        }
    }

    public void updateScreen() {
        this.inputField.updateCursorCounter();
    }

    public void keyTyped(char _char, int _code) {
        this.waitingOnPlayerNames = false;
        if (_code == 15) {
            this.completePlayerName();
            this.autocompleteTextEmote(this.inputField);
        } else {
            this.playerNamesFound = false;
        }
        if (_code == 1) {
            this.mc.displayGuiScreen((GuiScreen)null);
        } else if (_code == 28) {
            StringBuilder _msg = new StringBuilder(1500);
            for (int i = this.inputList.size() - 1; i >= 0; --i) {
                _msg.append(this.inputList.get(i).getText());
            }
            if (_msg.toString().length() > 0 && _msg.toString().length() < 100 && !_msg.toString().trim().equals("")) {
                String msgToWrite = _msg.toString();
                if (this.mc.handleClientCommand(msgToWrite)) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().addToSentMessages(msgToWrite);
                    for (int j = 1; j < this.inputList.size(); ++j) {
                        this.inputList.get(j).setText("");
                        this.inputList.get(j).setVisible(false);
                    }
                    this.mc.displayGuiScreen((GuiScreen)null);
                    return;
                }
                if (TabbyChat.instance.getActive().size() > 0 && (this.inputField.getText().matches("/.*") || !TabbyChat.instance.getActive().get(0).equals("Global")) && this.inputField.getText().length() >= 80) {
                    return;
                }
                if (this.inputField.getText().startsWith("/") && this.inputField.getText().length() >= 80) {
                    return;
                }
                if (TabbyChat.instance.getActive().size() > 0) {
                    if (ClientProxy.serverType.equals("build") && !_msg.toString().matches("^/.*") && TabbyChat.instance.getActive().get(0).matches("Ile [0-9]+")) {
                        msgToWrite = "/i msg [" + TabbyChat.instance.getActive().get(0) + "]" + msgToWrite;
                    } else if (!(_msg.toString().matches("^/.*") || TabbyChat.instance.getActive().get(0).equals("Global") || TabbyChat.instance.getActive().get(0).equals("Mon pays") || TabbyChat.instance.getActive().get(0).equals("ALL") || TabbyChat.instance.getActive().get(0).equals("ENE") || TabbyChat.instance.getActive().get(0).equals("ADMIN") || TabbyChat.instance.getActive().get(0).equals("MODO") || TabbyChat.instance.getActive().get(0).equals("Police") || TabbyChat.instance.getActive().get(0).equals("Mafia") || TabbyChat.instance.getActive().get(0).equals("Journal") || TabbyChat.instance.getActive().get(0).equals("Guide") || TabbyChat.instance.getActive().get(0).equals("Avocat") || TabbyChat.instance.getActive().get(0).equals("RP") || TabbyChat.instance.getActive().get(0).equals("Logs"))) {
                        msgToWrite = msgToWrite.substring(0, Math.min(80, msgToWrite.length()));
                        msgToWrite = "/m " + TabbyChat.instance.getActive().get(0) + " " + msgToWrite;
                    }
                }
                TabbyChatUtils.writeLargeChat(msgToWrite);
                for (int j = 1; j < this.inputList.size(); ++j) {
                    this.inputList.get(j).setText("");
                    this.inputList.get(j).setVisible(false);
                }
                this.mc.displayGuiScreen((GuiScreen)null);
            }
        } else if (_code == 200) {
            if (GuiScreen.isCtrlKeyDown()) {
                this.getSentHistory(-1);
            } else {
                int foc = this.getFocusedFieldInd();
                if (foc + 1 < this.inputList.size() && this.inputList.get(foc + 1).getVisible()) {
                    int gcp = this.inputList.get(foc).getCursorPosition();
                    int lng = this.inputList.get(foc + 1).getText().length();
                    int newPos = Math.min(gcp, lng);
                    this.inputList.get(foc).setFocused(false);
                    this.inputList.get(foc + 1).setFocused(true);
                    this.inputList.get(foc + 1).setCursorPosition(newPos);
                } else {
                    this.getSentHistory(-1);
                }
            }
        } else if (_code == 208) {
            if (GuiScreen.isCtrlKeyDown()) {
                this.getSentHistory(1);
            } else {
                int foc = this.getFocusedFieldInd();
                if (foc - 1 >= 0 && this.inputList.get(foc - 1).getVisible()) {
                    int gcp = this.inputList.get(foc).getCursorPosition();
                    int lng = this.inputList.get(foc - 1).getText().length();
                    int newPos = Math.min(gcp, lng);
                    this.inputList.get(foc).setFocused(false);
                    this.inputList.get(foc - 1).setFocused(true);
                    this.inputList.get(foc - 1).setCursorPosition(newPos);
                } else {
                    this.getSentHistory(1);
                }
            }
        } else if (_code == 201) {
            TabbyChat.gnc.scroll(19);
            if (tc.enabled()) {
                this.scrollBar.scrollBarMouseWheel();
            }
        } else if (_code == 209) {
            TabbyChat.gnc.scroll(-19);
            if (tc.enabled()) {
                this.scrollBar.scrollBarMouseWheel();
            }
        } else if (_code == 14) {
            if (this.inputField.isFocused() && this.inputField.getCursorPosition() > 0) {
                this.inputField.textboxKeyTyped(_char, _code);
            } else {
                this.removeCharsAtCursor(-1);
            }
        } else if (_code == 211) {
            if (this.inputField.isFocused()) {
                this.inputField.textboxKeyTyped(_char, _code);
            } else {
                this.removeCharsAtCursor(1);
            }
        } else if (_code == 203 || _code == 205) {
            this.inputList.get(this.getFocusedFieldInd()).textboxKeyTyped(_char, _code);
        } else if (this.inputField.isFocused() && this.fontRenderer.getStringWidth(this.inputField.getText()) < this.sr.getScaledWidth() - 20) {
            if (TabbyChat.instance.getActive().size() > 0 && (this.inputField.getText().matches("/.*") || !TabbyChat.instance.getActive().get(0).equals("Global")) && this.inputField.getText().length() >= 80) {
                return;
            }
            if ((this.inputField.getText().startsWith("/") || this.inputField.getText().startsWith("/") || this.inputField.getText().startsWith("/") || this.inputField.getText().startsWith("/")) && this.inputField.getText().length() >= 80) {
                return;
            }
            if (this.inputField.getText().length() < 99) {
                this.inputField.textboxKeyTyped(_char, _code);
            }
        } else {
            this.insertCharsAtCursor(Character.toString(_char));
        }
    }

    public void handleMouseInput() {
        int wheelDelta = Mouse.getEventDWheel();
        if (wheelDelta != 0) {
            wheelDelta = Math.min(1, wheelDelta);
            wheelDelta = Math.max(-1, wheelDelta);
            if (!GuiChatTC.isShiftKeyDown()) {
                wheelDelta *= 7;
            }
            TabbyChat.gnc.scroll(wheelDelta);
            if (tc.enabled()) {
                this.scrollBar.scrollBarMouseWheel();
            }
        } else if (tc.enabled()) {
            this.scrollBar.handleMouse();
        }
        if (this.mc.currentScreen.getClass() != GuiChat.class) {
            super.handleMouseInput();
        }
    }

    public void mouseMovedOrUp(int _x, int _y, int _button) {
        if (this.selectedButton != null && _button == 0) {
            this.selectedButton.mouseReleased(_x, _y);
            this.selectedButton = null;
        }
    }

    public void mouseClicked(int _x, int _y, int _button) {
        if (_button == 0 && this.mc.gameSettings.chatLinks) {
            String clickedProfil;
            String clickedCountry;
            URI url;
            ChatClickData ccd = TabbyChat.gnc.func_73766_a(Mouse.getX(), Mouse.getY());
            if (ccd != null && (url = ccd.getURI()) != null) {
                if (this.mc.gameSettings.chatLinksPrompt) {
                    this.clickedURI = url;
                    this.mc.displayGuiScreen((GuiScreen)new GuiConfirmOpenLink((GuiScreen)this, ccd.getClickedUrl(), 0, false));
                } else {
                    this.func_73896_a(url);
                }
                return;
            }
            ChatClickCountryData clickCountryData = TabbyChat.gnc.getClickedCountryData(Mouse.getX(), Mouse.getY());
            if (clickCountryData != null && (clickedCountry = clickCountryData.getCountry()) != null) {
                this.mc.displayGuiScreen((GuiScreen)new FactionGUI(clickCountryData.getCountry()));
                return;
            }
            ChatClickProfilData clickProfilData = TabbyChat.gnc.getClickedProfilData(Mouse.getX(), Mouse.getY());
            if (clickProfilData != null && (clickedProfil = clickProfilData.getProfil()) != null) {
                FactionGUI.factionInfos = null;
                this.mc.displayGuiScreen((GuiScreen)new ProfilGui(clickProfilData.getProfil(), ""));
                return;
            }
        } else if (_button == 1) {
            Object clickedProfil;
            ChatClickProfilData clickProfilData = TabbyChat.gnc.getClickedProfilData(Mouse.getX(), Mouse.getY());
            if (clickProfilData != null && (clickedProfil = clickProfilData.getProfil()) != null) {
                if (!GuiChatTC.tc.channelMap.containsKey(clickedProfil)) {
                    GuiChatTC.tc.channelMap.put((String)clickedProfil, new ChatChannel((String)clickedProfil));
                }
                for (ChatChannel chan : GuiChatTC.tc.channelMap.values()) {
                    chan.active = false;
                }
                GuiChatTC.tc.channelMap.get((Object)clickedProfil).active = true;
                tc.resetDisplayedChat();
                return;
            }
        }
        for (int i = 0; i < this.inputList.size(); ++i) {
            if (_y < this.height - 12 * (i + 1) || !this.inputList.get(i).getVisible()) continue;
            this.inputList.get(i).setFocused(true);
            for (GuiTextField field : this.inputList) {
                if (field == this.inputList.get(i)) continue;
                field.setFocused(false);
            }
            this.inputList.get(i).mouseClicked(_x, _y, _button);
            break;
        }
        if (_button == 0) {
            for (GuiButton _guibutton : this.buttonList) {
                if (!_guibutton.mousePressed(this.mc, _x, _y)) continue;
                this.selectedButton = _guibutton;
                this.mc.sndManager.playSoundFX("random.click", 1.0f, 1.0f);
                this.actionPerformed(_guibutton);
            }
        }
    }

    public void confirmClicked(boolean zeroId, int worldNum) {
        if (worldNum == 0) {
            if (zeroId) {
                this.func_73896_a(this.clickedURI);
            }
            this.clickedURI = null;
            this.mc.displayGuiScreen((GuiScreen)this);
        }
    }

    public void func_73896_a(URI _uri) {
        try {
            Class<?> desktop = Class.forName("java.awt.Desktop");
            Object theDesktop = desktop.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
            desktop.getMethod("browse", URI.class).invoke(theDesktop, _uri);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public void completePlayerName() {
        if (this.playerNamesFound) {
            this.inputField.deleteFromCursor(this.inputField.func_73798_a(-1, this.inputField.getCursorPosition(), false) - this.inputField.getCursorPosition());
            if (this.playerNameIndex >= this.foundPlayerNames.size()) {
                this.playerNameIndex = 0;
            }
        } else {
            int prevWordIndex = this.inputField.func_73798_a(-1, this.inputField.getCursorPosition(), false);
            this.foundPlayerNames.clear();
            this.playerNameIndex = 0;
            String nameStart = this.inputField.getText().substring(prevWordIndex).toLowerCase();
            String textBuffer = this.inputField.getText().substring(0, this.inputField.getCursorPosition());
            this.func_73893_a(textBuffer, nameStart);
            if (this.foundPlayerNames.isEmpty()) {
                return;
            }
            this.playerNamesFound = true;
            this.inputField.deleteFromCursor(prevWordIndex - this.inputField.getCursorPosition());
        }
        if (this.foundPlayerNames.size() > 1) {
            StringBuilder _sb = new StringBuilder();
            for (String textBuffer : this.foundPlayerNames) {
                if (_sb.length() > 0) {
                    _sb.append(", ");
                }
                _sb.append(textBuffer);
            }
            this.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(_sb.toString(), 1);
        }
        if (this.foundPlayerNames.size() > this.playerNameIndex) {
            this.inputField.writeText((String)this.foundPlayerNames.get(this.playerNameIndex));
            ++this.playerNameIndex;
        }
    }

    public void func_73893_a(String nameStart, String buffer) {
        if (nameStart.length() >= 1) {
            this.mc.thePlayer.sendQueue.addToSendQueue((Packet)new Packet203AutoComplete(nameStart));
            this.waitingOnPlayerNames = true;
        }
    }

    public void getSentHistory(int _dir) {
        int loc = this.sentHistoryCursor + _dir;
        int historyLength = TabbyChat.gnc.getSentMessages().size();
        loc = Math.max(0, loc);
        if ((loc = Math.min(historyLength, loc)) == this.sentHistoryCursor) {
            return;
        }
        if (loc == historyLength) {
            this.sentHistoryCursor = historyLength;
            this.setText(new StringBuilder(""), 1);
        } else {
            if (this.sentHistoryCursor == historyLength) {
                this.historyBuffer = this.inputField.getText();
            }
            StringBuilder _sb = new StringBuilder((String)TabbyChat.gnc.getSentMessages().get(loc));
            this.setText(_sb, _sb.length());
            this.sentHistoryCursor = loc;
        }
    }

    public void drawScreen(int cursorX, int cursorY, float pointless) {
        if (this.displayText && this.scrollBarObj != null) {
            Objective current = ClientData.objectives.get(ClientData.currentObjectiveIndex);
            GuiChatTC.drawRect((int)(this.width / 2 - 200), (int)(this.height / 2 - 125 + 25), (int)(this.width / 2 + 200), (int)(this.height / 2 + 125), (int)-301989888);
            GuiChatTC.drawRect((int)(this.width / 2 - 200), (int)(this.height / 2 - 125 + 5), (int)(this.width / 2 + 200), (int)(this.height / 2 - 125 + 25), (int)-1728053248);
            ClientEventHandler.STYLE.bindTexture("hud2");
            GL11.glColor3f((float)1.0f, (float)1.0f, (float)1.0f);
            this.drawTexturedModalRect(this.width / 2 - 200 + 5, this.height / 2 - 125 + 8, 2, 20, 13, 13);
            this.drawString(this.fontRenderer, current.getTitle(), this.width / 2 - 200 + 20, this.height / 2 - 125 + 11, 0xFFFFFF);
            GUIUtils.startGLScissor(this.width / 2 - 200, this.height / 2 - 125 + 5 + 30, 380, 185);
            GL11.glPushMatrix();
            if (this.lines.size() > 11) {
                GL11.glTranslatef((float)0.0f, (float)(-this.scrollBarObj.sliderValue * (float)((this.lines.size() - 11) * 12 + this.heightModifier)), (float)0.0f);
            }
            int i = 0;
            for (String line : this.lines) {
                this.drawString(this.fontRenderer, line, this.width / 2 - 200 + 10, this.height / 2 - 125 + 35 + i * 12, 0xFFFFFF);
                ++i;
            }
            ItemStack itemStack = ClientData.objectives.get(ClientData.currentObjectiveIndex).getItemStack();
            boolean dr = false;
            if (itemStack != null) {
                int itemY = this.lines.size() * 12 + 2;
                int tWidth = this.fontRenderer.getStringWidth(I18n.getString((String)"objectives.collect"));
                int w = tWidth + 16 + 4;
                this.fontRenderer.drawString(I18n.getString((String)"objectives.collect"), this.width / 2 - 10 - w / 2, this.height / 2 - 125 + 35 + itemY + 4, 0xFFFFFF);
                this.itemRenderer.renderItemAndEffectIntoGUI(this.fontRenderer, this.mc.getTextureManager(), itemStack, this.width / 2 - 10 - w / 2 + tWidth + 4, this.height / 2 - 125 + 35 + itemY);
                this.itemRenderer.renderItemOverlayIntoGUI(this.fontRenderer, this.mc.getTextureManager(), itemStack, this.width / 2 - 10 - w / 2 + tWidth + 4, this.height / 2 - 125 + 35 + itemY);
                int pX = this.width / 2 - 10 - w / 2 + tWidth + 4;
                int pY = this.height / 2 - 125 + 35 + itemY - (int)(this.scrollBarObj.sliderValue * (float)((this.lines.size() - 11) * 12 + this.heightModifier));
                dr = cursorX >= pX && cursorX <= pX + 18 && cursorY >= pY && cursorY <= pY + 18;
                GL11.glDisable((int)2896);
            }
            GL11.glPopMatrix();
            GUIUtils.endGLScissor();
            if (dr) {
                NationsGUIClientHooks.drawItemStackTooltip(itemStack, cursorX, cursorY);
                GL11.glDisable((int)2896);
            }
            this.scrollBarObj.draw(cursorX, cursorY);
        }
        if (this.displayEmotesGui) {
            float _mult = this.mc.gameSettings.chatOpacity * 0.9f + 0.1f;
            int _opacity = (int)(255.0f * _mult);
            GuiChatTC.drawRect((int)(this.width - 132), (int)(this.height - 134), (int)(this.width - 132 + 110), (int)(this.height - 134 + 120), (int)(_opacity / 2 << 24));
        }
        if (ClientData.currentAssault != null && !ClientData.currentAssault.isEmpty()) {
            int posYHelperAttacker;
            if (!ClientData.currentAssault.get("attackerHelpersCount").equals("0")) {
                int posXHelperAttacker = this.width - 140 + 23 + this.fontRenderer.getStringWidth(ClientData.currentAssault.get("attackerFactionName")) - 1;
                posYHelperAttacker = (int)((double)this.height * 0.4) + 26;
                if (cursorX >= posXHelperAttacker && cursorX <= posXHelperAttacker + 19 && cursorY >= posYHelperAttacker && cursorY <= posYHelperAttacker + 3) {
                    this.drawHoveringText(Arrays.asList(ClientData.currentAssault.get("attackerHelpersName").split(",")), cursorX, cursorY, this.fontRenderer);
                }
            }
            if (!ClientData.currentAssault.get("defenderHelpersCount").equals("0")) {
                int posXHelperAttacker = this.width - 140 + 23 + this.fontRenderer.getStringWidth(ClientData.currentAssault.get("defenderFactionName")) - 1;
                posYHelperAttacker = (int)((double)this.height * 0.4) + 26;
                if (cursorX >= posXHelperAttacker && cursorX <= posXHelperAttacker + 19 && cursorY >= posYHelperAttacker && cursorY <= posYHelperAttacker + 3) {
                    this.drawHoveringText(Arrays.asList(ClientData.currentAssault.get("defenderHelpersName").split(",")), cursorX, cursorY, this.fontRenderer);
                }
            }
        }
        boolean unicodeStore = this.fontRenderer.getUnicodeFlag();
        if (TabbyChat.instance.generalSettings.tabbyChatEnable.getValue().booleanValue() && ClientProxy.clientConfig.enableUnicode) {
            this.fontRenderer.setUnicodeFlag(true);
        }
        this.width = this.sr.getScaledWidth();
        this.height = this.sr.getScaledHeight();
        int inputHeight = 0;
        for (int i = 0; i < this.inputList.size(); ++i) {
            if (!this.inputList.get(i).getVisible()) continue;
            inputHeight += 12;
        }
        GuiChatTC.drawRect((int)2, (int)(this.height - 2 - inputHeight), (int)(this.width - 2), (int)(this.height - 2), (int)Integer.MIN_VALUE);
        for (GuiTextField field : this.inputList) {
            if (!field.getVisible()) continue;
            field.drawTextBox();
            this.autocompleteTooltipEmote(this.width, this.height, field);
        }
        if (!this.mc.isSingleplayer()) {
            this.drawChatTabs();
        }
        if (tc.enabled()) {
            this.scrollBar.drawScrollBar();
        }
        float scaleSetting = TabbyChat.gnc.getScaleSetting();
        GL11.glPushMatrix();
        float scaleOffset = (float)(this.sr.getScaledHeight() - 28) * (1.0f - scaleSetting);
        GL11.glTranslatef((float)0.0f, (float)scaleOffset, (float)1.0f);
        GL11.glScalef((float)scaleSetting, (float)scaleSetting, (float)1.0f);
        for (GuiButton _button : this.buttonList) {
            if (_button instanceof EmoteButton || _button instanceof SimpleButton || _button instanceof Button || _button instanceof EmoteOpenButton) {
                GL11.glScalef((float)(1.0f / scaleSetting), (float)(1.0f / scaleSetting), (float)1.0f);
                GL11.glTranslatef((float)0.0f, (float)(-scaleOffset), (float)1.0f);
                _button.drawButton(this.mc, cursorX, cursorY);
                GL11.glTranslatef((float)0.0f, (float)scaleOffset, (float)1.0f);
                GL11.glScalef((float)scaleSetting, (float)scaleSetting, (float)1.0f);
                continue;
            }
            _button.drawButton(this.mc, cursorX, cursorY);
        }
        GL11.glPopMatrix();
        this.fontRenderer.setUnicodeFlag(unicodeStore);
    }

    public void func_73894_a(String[] par1ArrayOfStr) {
        if (this.waitingOnPlayerNames) {
            this.foundPlayerNames.clear();
            String[] _copy = par1ArrayOfStr;
            int _len = par1ArrayOfStr.length;
            for (int i = 0; i < _len; ++i) {
                String name = _copy[i];
                if (name.length() <= 0) continue;
                this.foundPlayerNames.add(name);
            }
            if (this.foundPlayerNames.size() > 0) {
                this.playerNamesFound = true;
                this.completePlayerName();
            }
        }
    }

    public void actionPerformed(GuiButton par1GuiButton) {
        if (par1GuiButton instanceof ChatButton) {
            ChatButton _button = (ChatButton)par1GuiButton;
            if (Keyboard.isKeyDown((int)42) && GuiChatTC.tc.channelMap.get("Global") == _button.channel && (Minecraft.getMinecraft().thePlayer.getDisplayName().equalsIgnoreCase("iBalix") || Minecraft.getMinecraft().thePlayer.getDisplayName().equalsIgnoreCase("Mistersand"))) {
                this.mc.displayGuiScreen((GuiScreen)GuiChatTC.tc.generalSettings);
                return;
            }
            if (!tc.enabled()) {
                return;
            }
            if (Keyboard.isKeyDown((int)42) && GuiChatTC.tc.channelMap.get("Global") != _button.channel) {
                GuiChatTC.tc.channelMap.remove(_button.channel.title);
            } else {
                for (ChatChannel chan : GuiChatTC.tc.channelMap.values()) {
                    if (((Object)((Object)_button)).equals((Object)chan.tab)) continue;
                    chan.active = false;
                }
                if (!_button.channel.active) {
                    this.scrollBar.scrollBarMouseWheel();
                    _button.channel.active = true;
                    _button.channel.unread = false;
                    if (_button.channel.title.equals("Mon pays")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("FACTION")));
                    } else if (_button.channel.title.equals("ALL")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("ALLY")));
                    } else if (_button.channel.title.equals("ENE")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("ENEMY")));
                    } else if (_button.channel.title.equals("Global") && ClientProxy.serverType.equals("ng")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("PUBLIC")));
                    } else if (_button.channel.title.equals("ADMIN")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("ADMIN")));
                    } else if (_button.channel.title.equals("MODO")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("MOD")));
                    } else if (_button.channel.title.equals("Journal")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("UA")));
                    } else if (_button.channel.title.equals("Mafia")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("JrMod")));
                    } else if (_button.channel.title.equals("Police")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("SrMod")));
                    } else if (_button.channel.title.equals("Guide")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("JrAdmin")));
                    } else if (_button.channel.title.equals("Avocat")) {
                        PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ChatTabSetChatPacket("Avocat")));
                    }
                }
                tc.resetDisplayedChat();
            }
        } else {
            List<Objective> objectives = ClientData.objectives;
            if (par1GuiButton.id >= 10 && par1GuiButton.id < 10 + objectives.size()) {
                ClientData.currentObjectiveIndex = par1GuiButton.id - 10;
                this.displayText = true;
                this.generateTextLines();
            } else {
                switch (par1GuiButton.id) {
                    case 0: {
                        this.displayText = true;
                        this.generateTextLines();
                        break;
                    }
                    case 3: {
                        Objective current = ClientData.objectives.get(ClientData.currentObjectiveIndex);
                        if (current != null && current.getId().split("-").length == 3) {
                            PacketDispatcher.sendPacketToServer((Packet)PacketRegistry.INSTANCE.generatePacket(new ObjectivePacket()));
                        }
                        this.displayText = false;
                        break;
                    }
                    case 4: {
                        this.displayText = false;
                        break;
                    }
                    case 5: {
                        this.displayEmotesGui = !this.displayEmotesGui;
                        break;
                    }
                    case 6: {
                        if (ClientData.currentIsland != null && ClientData.currentIsland.size() > 0) {
                            if (ClientData.currentJumpStartTime == -1L) {
                                Minecraft.getMinecraft().displayGuiScreen((GuiScreen)new IslandMainGui());
                                break;
                            }
                            NationsGUI.islandsSaveJumpPosition(ClientData.currentJumpLocation, "stop", -1L);
                            ClientData.currentJumpRecord = "";
                            ClientData.currentJumpStartTime = -1L;
                            break;
                        }
                        NationsGUI.islandsSaveJumpPosition(ClientData.currentJumpLocation, "stop", -1L);
                        ClientData.currentJumpRecord = "";
                        ClientData.currentJumpStartTime = -1L;
                        break;
                    }
                    case 7: {
                        Minecraft.getMinecraft().displayGuiScreen((GuiScreen)new IslandListGui((EntityPlayer)Minecraft.getMinecraft().thePlayer));
                        break;
                    }
                    case 8: {
                        this.displayEmotesGui = false;
                    }
                }
            }
            if (this.displayEmotesGui && this.mappingButtonIdEmote.containsKey(par1GuiButton.id)) {
                this.inputField.setText(this.inputField.getText() + ":" + this.mappingButtonIdEmote.get(par1GuiButton.id) + ":");
            }
        }
    }

    public void drawChatTabs() {
        Double offsetY;
        this.buttonList.clear();
        this.mappingButtonIdEmote.clear();
        tc.updateButtonLocations();
        for (ChatChannel _chan : GuiChatTC.tc.channelMap.values()) {
            this.buttonList.add(_chan.tab);
        }
        int y = 30;
        if (ClientProxy.serverType.equals("ng") && ClientProxy.clientConfig.displayObjectives && !Minecraft.getMinecraft().gameSettings.showDebugInfo) {
            if (!this.displayText) {
                if (!ClientData.objectives.isEmpty()) {
                    int btnIndex = 10;
                    for (Objective objective : ClientData.objectives) {
                        this.buttonList.add(new Button(btnIndex, 4, y, 112, 29));
                        y += 34;
                        ++btnIndex;
                    }
                }
            } else {
                this.heightModifier = ClientData.objectives.get(ClientData.currentObjectiveIndex).getItemStack() != null ? 10 : 0;
                this.scrollBarObj = new ScrollBar(this.width / 2 + 200 - 15, this.height / 2 - 125 + 30, 185);
                if (ClientData.objectives.get(ClientData.currentObjectiveIndex).getItemStack() == null) {
                    this.buttonList.add(new SimpleButton(3, this.width / 2 + 200 - 56, this.height / 2 + 125 - 25, 50, 15, "Ok"));
                } else {
                    this.buttonList.add(new SimpleButton(4, this.width / 2 + 200 - 56, this.height / 2 + 125 - 25, 50, 15, "Ok"));
                    this.buttonList.add(new SimpleButton(3, this.width / 2 + 200 - 56 - 105, this.height / 2 + 125 - 25, 100, 15, I18n.getString((String)"objectives.validate")));
                }
            }
        }
        this.buttonList.add(new EmoteOpenButton(5, this.width - 34, this.height - 14, 12, 12));
        int buttonIndex = 0;
        int emoteWidth = this.width - 131 + buttonIndex % 5 * 22;
        int emoteHeight = this.height - 134 + buttonIndex / 5 * 20;
        for (Map.Entry<String, String> pair : NationsGUI.EMOTES_SYMBOLS.entrySet()) {
            if (!NationsGUI.EMOTES_RESOURCES.containsKey(pair.getKey())) continue;
            this.buttonList.add(new EmoteButton(100 + buttonIndex, emoteWidth, emoteHeight, 22, 20, pair.getKey()));
            this.mappingButtonIdEmote.put(100 + buttonIndex, pair.getKey());
            emoteWidth = this.width - 131 + ++buttonIndex % 5 * 22;
            emoteHeight = this.height - 134 + buttonIndex / 5 * 20;
        }
        if (ClientData.currentIsland != null && ClientData.currentIsland.size() > 0) {
            offsetY = (double)this.height * 0.4 + 78.0;
            this.buttonList.add(new VoidButton(6, this.width - 120 + 13, offsetY.intValue(), 94, 15));
            this.buttonList.add(new VoidButton(7, this.width - 120 + 13, offsetY.intValue() + 20, 94, 15));
        } else if (!ClientData.currentJumpLocation.isEmpty()) {
            offsetY = (double)this.height * 0.4 + 80.0;
            this.buttonList.add(new VoidButton(6, this.width - 140, offsetY.intValue(), 140, 16));
        }
    }

    public int getFocusedFieldInd() {
        int _s = this.inputList.size();
        for (int i = 0; i < _s; ++i) {
            if (!this.inputList.get(i).isFocused() || !this.inputList.get(i).getVisible()) continue;
            return i;
        }
        return 0;
    }

    public void removeCharsAtCursor(int _del) {
        StringBuilder msg = new StringBuilder();
        int cPos = 0;
        boolean cFound = false;
        for (int i = this.inputList.size() - 1; i >= 0; --i) {
            msg.append(this.inputList.get(i).getText());
            if (this.inputList.get(i).isFocused()) {
                cPos += this.inputList.get(i).getCursorPosition();
                cFound = true;
                continue;
            }
            if (cFound) continue;
            cPos += this.inputList.get(i).getText().length();
        }
        int other = cPos + _del;
        other = Math.min(msg.length() - 1, other);
        if ((other = Math.max(0, other)) < cPos) {
            msg.replace(other, cPos, "");
            this.setText(msg, other);
        } else if (other > cPos) {
            msg.replace(cPos, other, "");
            this.setText(msg, cPos);
        } else {
            return;
        }
    }

    public void insertCharsAtCursor(String _chars) {
        StringBuilder msg = new StringBuilder();
        int cPos = 0;
        boolean cFound = false;
        for (int i = this.inputList.size() - 1; i >= 0; --i) {
            msg.append(this.inputList.get(i).getText());
            if (this.inputList.get(i).isFocused()) {
                cPos += this.inputList.get(i).getCursorPosition();
                cFound = true;
                continue;
            }
            if (cFound) continue;
            cPos += this.inputList.get(i).getText().length();
        }
        if (this.fontRenderer.getStringWidth(msg.toString()) + this.fontRenderer.getStringWidth(_chars) < (this.sr.getScaledWidth() - 20) * this.inputList.size()) {
            msg.insert(cPos, _chars);
            this.setText(msg, cPos + _chars.length());
        }
    }

    public void setText(StringBuilder txt, int pos) {
        int strings;
        List<String> txtList = this.stringListByWidth(txt, this.sr.getScaledWidth() - 20);
        for (int i = strings = Math.min(txtList.size() - 1, this.inputList.size() - 1); i >= 0; --i) {
            this.inputList.get(i).setText(txtList.get(strings - i));
            if (pos > txtList.get(strings - i).length()) {
                pos -= txtList.get(strings - i).length();
                this.inputList.get(i).setVisible(true);
                this.inputList.get(i).setFocused(false);
                continue;
            }
            if (pos >= 0) {
                this.inputList.get(i).setFocused(true);
                this.inputList.get(i).setVisible(true);
                this.inputList.get(i).setCursorPosition(pos);
                pos = -1;
                continue;
            }
            this.inputList.get(i).setVisible(true);
            this.inputList.get(i).setFocused(false);
        }
        if (pos > 0) {
            this.inputField.setCursorPositionEnd();
        }
        if (this.inputList.size() > txtList.size()) {
            for (int j = txtList.size(); j < this.inputList.size(); ++j) {
                this.inputList.get(j).setText("");
                this.inputList.get(j).setFocused(false);
                this.inputList.get(j).setVisible(false);
            }
        }
        if (!this.inputField.getVisible()) {
            this.inputField.setVisible(true);
            this.inputField.setFocused(true);
        }
    }

    public List<String> stringListByWidth(StringBuilder _sb, int _w) {
        ArrayList<String> result = new ArrayList<String>(5);
        int _len = 0;
        StringBuilder bucket = new StringBuilder(_sb.length());
        for (int ind = 0; ind < _sb.length(); ++ind) {
            int _cw = this.fontRenderer.getCharWidth(_sb.charAt(ind));
            if (_len + _cw > _w) {
                result.add(bucket.toString());
                bucket = new StringBuilder(_sb.length());
                _len = 0;
            }
            _len += _cw;
            bucket.append(_sb.charAt(ind));
        }
        if (bucket.length() > 0) {
            result.add(bucket.toString());
        }
        return result;
    }

    public int getCurrentSends() {
        int _s;
        int lng = 0;
        for (int i = _s = this.inputList.size() - 1; i >= 0; --i) {
            lng += this.inputList.get(i).getText().length();
        }
        if (lng == 0) {
            return 0;
        }
        return (int)Math.ceil((float)lng / 100.0f);
    }

    private void generateTextLines() {
        String[] l;
        this.lines.clear();
        int lineWidth = 360;
        int spaceWidth = this.fontRenderer.getStringWidth(" ");
        Objective current = ClientData.objectives.get(ClientData.currentObjectiveIndex);
        for (String line : l = current.getText().split("\n")) {
            int spaceLeft = lineWidth;
            String[] words = line.split(" ");
            StringBuilder stringBuilder = new StringBuilder();
            for (String word : words) {
                int wordWidth = this.fontRenderer.getStringWidth(word);
                if (wordWidth + spaceWidth > spaceLeft) {
                    this.lines.add(stringBuilder.toString());
                    stringBuilder = new StringBuilder();
                    spaceLeft = lineWidth - wordWidth;
                } else {
                    spaceLeft -= wordWidth + spaceWidth;
                }
                stringBuilder.append(word);
                stringBuilder.append(' ');
            }
            this.lines.add(stringBuilder.toString());
        }
    }

    protected void drawHoveringText(List par1List, int par2, int par3, FontRenderer font) {
        if (!par1List.isEmpty()) {
            GL11.glDisable((int)32826);
            RenderHelper.disableStandardItemLighting();
            GL11.glDisable((int)2896);
            GL11.glDisable((int)2929);
            int k = 0;
            for (String s : par1List) {
                int l = font.getStringWidth(s);
                if (l <= k) continue;
                k = l;
            }
            int i1 = par2 + 12;
            int j1 = par3 - 12;
            int k1 = 8;
            if (par1List.size() > 1) {
                k1 += 2 + (par1List.size() - 1) * 10;
            }
            if (i1 + k > this.width) {
                i1 -= 28 + k;
            }
            if (j1 + k1 + 6 > this.height) {
                j1 = this.height - k1 - 6;
            }
            this.zLevel = 300.0f;
            this.itemRenderer.zLevel = 300.0f;
            int l1 = -267386864;
            this.drawGradientRect(i1 - 3, j1 - 4, i1 + k + 3, j1 - 3, l1, l1);
            this.drawGradientRect(i1 - 3, j1 + k1 + 3, i1 + k + 3, j1 + k1 + 4, l1, l1);
            this.drawGradientRect(i1 - 3, j1 - 3, i1 + k + 3, j1 + k1 + 3, l1, l1);
            this.drawGradientRect(i1 - 4, j1 - 3, i1 - 3, j1 + k1 + 3, l1, l1);
            this.drawGradientRect(i1 + k + 3, j1 - 3, i1 + k + 4, j1 + k1 + 3, l1, l1);
            int i2 = 0x505000FF;
            int j2 = (i2 & 0xFEFEFE) >> 1 | i2 & 0xFF000000;
            this.drawGradientRect(i1 - 3, j1 - 3 + 1, i1 - 3 + 1, j1 + k1 + 3 - 1, i2, j2);
            this.drawGradientRect(i1 + k + 2, j1 - 3 + 1, i1 + k + 3, j1 + k1 + 3 - 1, i2, j2);
            this.drawGradientRect(i1 - 3, j1 - 3, i1 + k + 3, j1 - 3 + 1, i2, i2);
            this.drawGradientRect(i1 - 3, j1 + k1 + 2, i1 + k + 3, j1 + k1 + 3, j2, j2);
            for (int k2 = 0; k2 < par1List.size(); ++k2) {
                String s1 = (String)par1List.get(k2);
                font.drawStringWithShadow(s1, i1, j1, -1);
                if (k2 == 0) {
                    j1 += 2;
                }
                j1 += 10;
            }
            this.zLevel = 0.0f;
            this.itemRenderer.zLevel = 0.0f;
            GL11.glDisable((int)2896);
            GL11.glDisable((int)2929);
            GL11.glEnable((int)32826);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    public void autocompleteTooltipEmote(int guiWidth, int guiHeight, GuiTextField textField) {
        Pattern pattern = Pattern.compile(":([a-z0-9]+)$");
        Matcher m = pattern.matcher(textField.getText());
        if (m.find()) {
            String emoteToAutocomplete = m.group(1);
            ArrayList<String> emoteWhichMatch = new ArrayList<String>();
            for (Map.Entry<String, ResourceLocation> pair : NationsGUI.EMOTES_RESOURCES.entrySet()) {
                String emoteName = pair.getKey();
                pattern = Pattern.compile("^" + emoteToAutocomplete);
                m = pattern.matcher(emoteName);
                if (!m.find()) continue;
                emoteWhichMatch.add(":" + emoteName + ":");
            }
            if (emoteWhichMatch.size() > 0) {
                this.drawHoveringText(emoteWhichMatch, Minecraft.getMinecraft().fontRenderer.getStringWidth(textField.getText()), guiHeight - 14 - emoteWhichMatch.size() * 9, Minecraft.getMinecraft().fontRenderer);
            }
        }
    }

    public void autocompleteTextEmote(GuiTextField textField) {
        Pattern pattern = Pattern.compile(":([a-z0-9]+)$");
        Matcher m = pattern.matcher(textField.getText());
        if (m.find()) {
            String emoteToAutocomplete = m.group(1);
            String emoteWhichMatch = null;
            for (Map.Entry<String, ResourceLocation> pair : NationsGUI.EMOTES_RESOURCES.entrySet()) {
                String emoteName = pair.getKey();
                pattern = Pattern.compile("^" + emoteToAutocomplete);
                m = pattern.matcher(emoteName);
                if (!m.find()) continue;
                emoteWhichMatch = ":" + emoteName + ":";
            }
            if (emoteWhichMatch != null) {
                textField.setText(textField.getText() + emoteWhichMatch.replace(":" + emoteToAutocomplete, "") + " ");
            }
        }
    }

    static {
        tc = TabbyChat.instance;
    }

    private class ScrollBar
    extends GuiScrollBar {
        public ScrollBar(float x, float y, int height) {
            super(x, y, height);
        }

        @Override
        protected void drawScroller() {
            ScrollBar.drawRect((int)((int)this.x), (int)((int)this.y), (int)((int)(this.x + 9.0f)), (int)((int)(this.y + (float)this.height)), (int)0x22FFFFFF);
            int yP = (int)(this.y + (float)(this.height - 20) * this.sliderValue);
            ScrollBar.drawRect((int)((int)this.x), (int)yP, (int)((int)(this.x + 9.0f)), (int)(yP + 20), (int)0x55FFFFFF);
        }
    }

    private class SimpleButton
    extends GuiButton {
        public SimpleButton(int p_i1021_1_, int p_i1021_2_, int p_i1021_3_, int p_i1021_4_, int p_i1021_5_, String p_i1021_6_) {
            super(p_i1021_1_, p_i1021_2_, p_i1021_3_, p_i1021_4_, p_i1021_5_, p_i1021_6_);
        }

        public void drawButton(Minecraft par1Minecraft, int par2, int par3) {
            this.field_82253_i = par2 >= this.xPosition && par3 >= this.yPosition && par2 < this.xPosition + this.width && par3 < this.yPosition + this.height;
            GL11.glColor3f((float)1.0f, (float)1.0f, (float)1.0f);
            SimpleButton.drawRect((int)this.xPosition, (int)this.yPosition, (int)(this.xPosition + this.width), (int)(this.yPosition + this.height), (int)(this.field_82253_i ? 0x77FFFFFF : 0x55FFFFFF));
            GuiChatTC.this.fontRenderer.drawString(this.displayString, this.xPosition + this.width / 2 - GuiChatTC.this.fontRenderer.getStringWidth(this.displayString) / 2, this.yPosition + 4, 0xFFFFFF);
        }
    }

    private class EmoteButton
    extends GuiButton {
        private String emoteName;

        public EmoteButton(int id, int posX, int posY, int width, int height, String emoteName) {
            super(id, posX, posY, width, height, "");
            this.emoteName = emoteName;
        }

        public void drawButton(Minecraft par1Minecraft, int par2, int par3) {
            if (GuiChatTC.this.displayEmotesGui) {
                this.field_82253_i = par2 >= this.xPosition && par3 >= this.yPosition && par2 < this.xPosition + this.width && par3 < this.yPosition + this.height;
                float _mult = ((GuiChatTC)GuiChatTC.this).mc.gameSettings.chatOpacity * 0.9f + 0.1f;
                if (this.field_82253_i) {
                    _mult *= 0.5f;
                }
                int _opacity = (int)(255.0f * _mult);
                EmoteButton.drawRect((int)this.xPosition, (int)this.yPosition, (int)(this.xPosition + this.width), (int)(this.yPosition + this.height), (int)(_opacity / 2 << 24));
                Double scale = 0.6;
                GL11.glPushMatrix();
                GL11.glScaled((double)scale, (double)scale, (double)scale);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                if (NationsGUI.EMOTES_RESOURCES.containsKey(this.emoteName)) {
                    Minecraft.getMinecraft().getTextureManager().bindTexture(NationsGUI.EMOTES_RESOURCES.get(this.emoteName));
                    ModernGui.drawModalRectWithCustomSizedTexture((float)this.xPosition * (1.0f / scale.floatValue()) + 8.0f, (float)this.yPosition * (1.0f / scale.floatValue()) + 7.0f, 0, 0, 18, 18, 18.0f, 18.0f, true);
                }
                GL11.glPopMatrix();
            }
        }
    }

    private class EmoteOpenButton
    extends GuiButton {
        public EmoteOpenButton(int id, int posX, int posY, int width, int height) {
            super(id, posX, posY, width, height, "\u263a");
        }

        public void drawButton(Minecraft par1Minecraft, int par2, int par3) {
            this.field_82253_i = par2 >= this.xPosition && par3 >= this.yPosition && par2 < this.xPosition + this.width && par3 < this.yPosition + this.height;
            int l = 0xE0E0E0;
            if (this.field_82253_i) {
                l = 0xFFFFA0;
            }
            float _mult = ((GuiChatTC)GuiChatTC.this).mc.gameSettings.chatOpacity * 0.9f + 0.1f;
            int _opacity = (int)(255.0f * _mult);
            EmoteOpenButton.drawRect((int)this.xPosition, (int)this.yPosition, (int)(this.xPosition + this.width), (int)(this.yPosition + this.height), (int)(_opacity / 2 << 24));
            this.drawCenteredString(Minecraft.getMinecraft().fontRenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
        }
    }

    public class VoidButton
    extends GuiButton {
        public VoidButton(int id, int posX, int posY, int width, int height) {
            super(id, posX, posY, width, height, "");
        }

        public void drawButton(Minecraft par1Minecraft, int par2, int par3) {
        }
    }

    private class Button
    extends GuiButton {
        public Button(int id, int posX, int posY, int width, int height) {
            super(id, posX, posY, width, height, "");
        }

        public void drawButton(Minecraft par1Minecraft, int par2, int par3) {
            this.field_82253_i = par2 >= this.xPosition && par3 >= this.yPosition && par2 < this.xPosition + this.width && par3 < this.yPosition + this.height;
        }
    }
}

