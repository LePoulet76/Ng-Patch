package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class AchievementsDataPacket$1 extends TypeToken<ArrayList<HashMap<String, String>>>
{
    final AchievementsDataPacket this$0;

    AchievementsDataPacket$1(AchievementsDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
