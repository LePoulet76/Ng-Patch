package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseBetDataPacket$1 extends TypeToken<HashMap<String, String>>
{
    final EnterpriseBetDataPacket this$0;

    EnterpriseBetDataPacket$1(EnterpriseBetDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
