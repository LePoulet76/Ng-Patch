package net.ilexiconn.nationsgui.forge.server.json.registry;

import com.google.common.reflect.TypeToken;
import com.google.gson.JsonElement;
import java.util.Map;

final class JSONRegistries$1 extends TypeToken<Map<String, JsonElement>>
{
}
