package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionSkillsPlayersLeaderboardDataPacket$2 extends TypeToken<HashMap<String, Double>>
{
    final FactionSkillsPlayersLeaderboardDataPacket this$0;

    FactionSkillsPlayersLeaderboardDataPacket$2(FactionSkillsPlayersLeaderboardDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
