package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseBankSalaryPacket$1 extends TypeToken<HashMap<String, Integer>>
{
    final EnterpriseBankSalaryPacket this$0;

    EnterpriseBankSalaryPacket$1(EnterpriseBankSalaryPacket this$0)
    {
        this.this$0 = this$0;
    }
}
