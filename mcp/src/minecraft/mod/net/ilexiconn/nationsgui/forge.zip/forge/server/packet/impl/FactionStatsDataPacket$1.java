package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;

class FactionStatsDataPacket$1 extends TypeToken<LinkedHashMap<Date, Double>>
{
    final FactionStatsDataPacket this$0;

    FactionStatsDataPacket$1(FactionStatsDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
