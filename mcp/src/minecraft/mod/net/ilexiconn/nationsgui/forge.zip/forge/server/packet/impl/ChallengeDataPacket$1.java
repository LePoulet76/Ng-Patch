package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;

class ChallengeDataPacket$1 extends TypeToken<ArrayList<String>>
{
    final ChallengeDataPacket this$0;

    ChallengeDataPacket$1(ChallengeDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
