package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionAdminEnemyListPacket$1 extends TypeToken<ArrayList<HashMap<String, Object>>>
{
    final FactionAdminEnemyListPacket this$0;

    FactionAdminEnemyListPacket$1(FactionAdminEnemyListPacket this$0)
    {
        this.this$0 = this$0;
    }
}
