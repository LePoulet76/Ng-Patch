package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.LinkedHashMap;

class FactionNewMembersDataPacket$1 extends TypeToken<LinkedHashMap<String, Object>>
{
    final FactionNewMembersDataPacket this$0;

    FactionNewMembersDataPacket$1(FactionNewMembersDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
