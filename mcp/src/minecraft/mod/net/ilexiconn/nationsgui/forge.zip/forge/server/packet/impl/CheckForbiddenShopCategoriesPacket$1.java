package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.List;

class CheckForbiddenShopCategoriesPacket$1 extends TypeToken<List<String>>
{
    final CheckForbiddenShopCategoriesPacket this$0;

    CheckForbiddenShopCategoriesPacket$1(CheckForbiddenShopCategoriesPacket this$0)
    {
        this.this$0 = this$0;
    }
}
