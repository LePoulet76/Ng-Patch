package net.ilexiconn.nationsgui.forge.server.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * Stub serveur pour SpeakerBlock, sans logique client.
 */
public class SpeakerBlock extends Block {
    public SpeakerBlock() {
        super(Material.rock);
    }
}
