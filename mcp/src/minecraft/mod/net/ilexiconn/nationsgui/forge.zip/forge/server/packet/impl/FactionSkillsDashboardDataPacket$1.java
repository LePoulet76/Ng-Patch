package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionSkillsDashboardDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionSkillsDashboardDataPacket this$0;

    FactionSkillsDashboardDataPacket$1(FactionSkillsDashboardDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
