/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package acs.tabbychat;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import acs.tabbychat.TCSetting;
import net.minecraft.client.Minecraft;

@SideOnly(value=Side.CLIENT)
public class TCSettingEnum
extends TCSetting {
    protected Enum value;
    protected Enum tempValue;

    public TCSettingEnum(String theLabel, int theID) {
        super(theLabel, theID);
        this.value = null;
        this.tempValue = null;
    }

    public TCSettingEnum(Enum theVar, String theLabel, int theID) {
        super(theLabel, theID);
        mc = Minecraft.getMinecraft();
        this.value = theVar;
        this.tempValue = theVar;
        this.description = theLabel;
        this.type = "enum";
        this.labelX = 0;
        this.width = 30;
        this.height = 11;
    }

    public void next() {
        Enum[] E = (Enum[])this.tempValue.getClass().getEnumConstants();
        Object tmp = this.tempValue.ordinal() == E.length - 1 ? Enum.valueOf(this.tempValue.getClass(), E[0].name()) : Enum.valueOf(this.tempValue.getClass(), E[this.tempValue.ordinal() + 1].name());
        this.tempValue = (Enum<?>) tmp;
    }

    public void previous() {
        Enum[] E = (Enum[])this.tempValue.getClass().getEnumConstants();
        this.tempValue = this.tempValue.ordinal() == 0 ? Enum.valueOf(this.tempValue.getClass(), E[E.length - 1].name()) : Enum.valueOf(this.tempValue.getClass(), E[this.tempValue.ordinal() - 1].name());
    }

    @Override
    public void save() {
        this.value = Enum.valueOf(this.tempValue.getClass(), this.tempValue.name());
    }

    @Override
    public void reset() {
        this.tempValue = Enum.valueOf(this.value.getClass(), this.value.name());
    }

    public void setValue(Enum theVal) {
        this.value = Enum.valueOf(theVal.getClass(), theVal.name());
    }

    public void setTempValue(Enum theVal) {
        this.tempValue = Enum.valueOf(theVal.getClass(), theVal.name());
    }

    @Override
    public Enum getValue() {
        return this.value;
    }

    @Override
    public Enum getTempValue() {
        return this.tempValue;
    }

    @Override
    public void mouseClicked(int par1, int par2, int par3) {
        if (this.hovered(par1, par2).booleanValue() && this.enabled) {
            if (par3 == 1) {
                this.previous();
            } else if (par3 == 0) {
                this.next();
            }
        }
    }

    @Override
    public void actionPerformed() {
    }

    @Override
    public void drawButton(Minecraft par1, int cursorX, int cursorY) {
        int centerX = this.xPosition + this.width / 2;
        int centerY = this.yPosition + this.height / 2;
        int fgcolor = -1717526368;
        if (!this.enabled) {
            fgcolor = 0x66A0A0A0;
        } else if (this.hovered(cursorX, cursorY).booleanValue()) {
            fgcolor = -1711276128;
        }
        int labelColor = this.enabled ? 0xFFFFFF : 0x666666;
        TCSettingEnum.drawRect((int)(this.xPosition + 1), (int)this.yPosition, (int)(this.xPosition + this.width - 1), (int)(this.yPosition + 1), (int)fgcolor);
        TCSettingEnum.drawRect((int)(this.xPosition + 1), (int)(this.yPosition + this.height - 1), (int)(this.xPosition + this.width - 1), (int)(this.yPosition + this.height), (int)fgcolor);
        TCSettingEnum.drawRect((int)this.xPosition, (int)(this.yPosition + 1), (int)(this.xPosition + 1), (int)(this.yPosition + this.height - 1), (int)fgcolor);
        TCSettingEnum.drawRect((int)(this.xPosition + this.width - 1), (int)(this.yPosition + 1), (int)(this.xPosition + this.width), (int)(this.yPosition + this.height - 1), (int)fgcolor);
        TCSettingEnum.drawRect((int)(this.xPosition + 1), (int)(this.yPosition + 1), (int)(this.xPosition + this.width - 1), (int)(this.yPosition + this.height - 1), (int)-16777216);
        this.drawCenteredString(Minecraft.getMinecraft().fontRenderer, this.tempValue.toString(), centerX, this.yPosition + 2, labelColor);
        this.drawCenteredString(Minecraft.getMinecraft().fontRenderer, this.description, this.labelX + Minecraft.getMinecraft().fontRenderer.getStringWidth(this.description) / 2, this.yPosition + (this.height - 6) / 2, labelColor);
    }
}

