package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

class CosmeticCategoryDataPacket$1 extends TypeToken<LinkedHashMap<String, ArrayList<HashMap<String, String>>>>
{
    final CosmeticCategoryDataPacket this$0;

    CosmeticCategoryDataPacket$1(CosmeticCategoryDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
