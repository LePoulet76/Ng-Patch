package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.TreeMap;

class FactionDiplomatieDataPacket$1 extends TypeToken<TreeMap<String, Object>>
{
    final FactionDiplomatieDataPacket this$0;

    FactionDiplomatieDataPacket$1(FactionDiplomatieDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
