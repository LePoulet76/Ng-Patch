package acs.tabbychat;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;

@SideOnly(Side.CLIENT)
public class BackgroundChatThread extends Thread {
    private String sendChat;

    public BackgroundChatThread(String toSend) {
        this.sendChat = toSend;
    }

    public void run() {
        Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(sendChat);
    }
}
