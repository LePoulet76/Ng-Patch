package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionWildernessDataPacket$1 extends TypeToken<ArrayList<HashMap<String, String>>>
{
    final FactionWildernessDataPacket this$0;

    FactionWildernessDataPacket$1(FactionWildernessDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
