package acs.proxy;

public class CommonProxy {
    public void initRenderers() {
        // Rien côté serveur
    }

    public void playNotificationSound() {
        // Aucun son côté serveur
    }

    public boolean isTimestampEnabled() {
        return false; // Côté serveur : pas de timestamp
    }
    public boolean isTagEnabled() {
    return false;
    }
}
