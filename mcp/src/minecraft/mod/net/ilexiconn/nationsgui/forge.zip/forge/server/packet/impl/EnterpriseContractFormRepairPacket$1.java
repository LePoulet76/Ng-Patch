package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseContractFormRepairPacket$1 extends TypeToken<HashMap<String, String>>
{
    final EnterpriseContractFormRepairPacket this$0;

    EnterpriseContractFormRepairPacket$1(EnterpriseContractFormRepairPacket this$0)
    {
        this.this$0 = this$0;
    }
}
