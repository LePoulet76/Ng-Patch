package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

class EnterpriseFarmDataPacket$2 extends TypeToken<Map<String, LinkedHashMap<Date, Double>>>
{
    final EnterpriseFarmDataPacket this$0;

    EnterpriseFarmDataPacket$2(EnterpriseFarmDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
