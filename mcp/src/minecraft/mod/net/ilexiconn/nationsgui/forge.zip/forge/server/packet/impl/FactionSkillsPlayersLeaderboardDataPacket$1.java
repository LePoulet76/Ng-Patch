package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.List;

class FactionSkillsPlayersLeaderboardDataPacket$1 extends TypeToken<HashMap<String, List<String>>>
{
    final FactionSkillsPlayersLeaderboardDataPacket this$0;

    FactionSkillsPlayersLeaderboardDataPacket$1(FactionSkillsPlayersLeaderboardDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
