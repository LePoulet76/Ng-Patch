package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseContractFormPvpPacket$1 extends TypeToken<HashMap<String, String>>
{
    final EnterpriseContractFormPvpPacket this$0;

    EnterpriseContractFormPvpPacket$1(EnterpriseContractFormPvpPacket this$0)
    {
        this.this$0 = this$0;
    }
}
