package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionActionsDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionActionsDataPacket this$0;

    FactionActionsDataPacket$1(FactionActionsDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
