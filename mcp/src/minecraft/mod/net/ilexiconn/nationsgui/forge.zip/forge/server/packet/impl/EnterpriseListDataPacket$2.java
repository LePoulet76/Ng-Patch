package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.List;

class EnterpriseListDataPacket$2 extends TypeToken<List<String>>
{
    final EnterpriseListDataPacket this$0;

    EnterpriseListDataPacket$2(EnterpriseListDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
