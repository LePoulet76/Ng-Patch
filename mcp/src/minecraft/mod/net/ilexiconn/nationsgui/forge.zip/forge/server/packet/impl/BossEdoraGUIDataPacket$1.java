package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class BossEdoraGUIDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final BossEdoraGUIDataPacket this$0;

    BossEdoraGUIDataPacket$1(BossEdoraGUIDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
