package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.List;

class FactionSkillsCountriesLeaderboardDataPacket$1 extends TypeToken<HashMap<String, List<String>>>
{
    final FactionSkillsCountriesLeaderboardDataPacket this$0;

    FactionSkillsCountriesLeaderboardDataPacket$1(FactionSkillsCountriesLeaderboardDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
