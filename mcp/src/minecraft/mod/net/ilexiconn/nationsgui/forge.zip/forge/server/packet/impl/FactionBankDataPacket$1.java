package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionBankDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionBankDataPacket this$0;

    FactionBankDataPacket$1(FactionBankDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
