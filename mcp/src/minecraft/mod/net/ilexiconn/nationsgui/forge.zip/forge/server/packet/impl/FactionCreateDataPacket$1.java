package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.common.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionCreateDataPacket$1 extends TypeToken<ArrayList<HashMap<String, String>>>
{
    final FactionCreateDataPacket this$0;

    FactionCreateDataPacket$1(FactionCreateDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
