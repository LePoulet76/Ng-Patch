package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class EnterpriseBetDataPacket$2 extends TypeToken<ArrayList<HashMap<String, Object>>>
{
    final EnterpriseBetDataPacket this$0;

    EnterpriseBetDataPacket$2(EnterpriseBetDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
