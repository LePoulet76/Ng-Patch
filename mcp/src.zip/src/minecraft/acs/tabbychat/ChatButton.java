package acs.tabbychat;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.I18n;
import org.lwjgl.opengl.GL11;

import java.util.Arrays;
import java.util.List;

@SideOnly(Side.CLIENT)
public class ChatButton extends GuiButton {
    public boolean visible = true;
    public acs.tabbychat.ChatChannel channel;
    public static RenderItem itemRenderer = new RenderItem();


    public ChatButton() {
        super(9999, 0, 0, 1, 1, "");
    }

    public ChatButton(int id, int x, int y, int w, int h, String title) {
        super(id, x, y, w, h, title);
    }

    protected int width() {
        return this.width;
    }

    public void width(int w) {
        this.width = w;
    }

    public int getButtonWidth() {
    return this.width;
    }

    public int height() {
        return this.height;
    }

    public int getHeight() {
        return this.height;
    }

    protected void height(int h) {
        this.height = h;
    }

    public void clear() {
        this.channel = null;
    }

    public boolean isMouseOver(Minecraft mc, int mouseX, int mouseY) {
        float scale = acs.tabbychat.TabbyChat.gnc.getScaleSetting();
        int adjY = (int)((float)(mc.currentScreen.height - this.yPosition - 28) * (1.0f - scale)) + this.yPosition;
        int adjX = (int)((float)(this.xPosition - 5) * scale) + 5;
        int adjW = (int)((float)this.width * scale);
        int adjH = (int)((float)this.height * scale);
        return this.enabled && this.visible && mouseX >= adjX && mouseY >= adjY && mouseX < adjX + adjW && mouseY < adjY + adjH;
    }
}
