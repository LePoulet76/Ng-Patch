package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.ilexiconn.nationsgui.forge.client.gui.FrameGui;
import net.ilexiconn.nationsgui.forge.server.packet.IClientPacket;
import net.ilexiconn.nationsgui.forge.server.packet.IPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class FrameOpenGuiPacket implements IPacket, IClientPacket
{
    private String url;
    private String title;
    private String musicUrl;

    public FrameOpenGuiPacket(String url, String title, String musicUrl)
    {
        this.url = url;
        this.title = title;
        this.musicUrl = musicUrl;
    }

    public void fromBytes(ByteArrayDataInput data)
    {
        this.url = data.readUTF();
        this.title = data.readUTF();
        this.musicUrl = data.readUTF();
    }

    public void toBytes(ByteArrayDataOutput data)
    {
        data.writeUTF(this.url);
        data.writeUTF(this.title);
        data.writeUTF(this.musicUrl);
    }

    @SideOnly(Side.CLIENT)
    public void handleClientPacket(EntityPlayer player)
    {
        Minecraft.getMinecraft().displayGuiScreen(new FrameGui(this.url, this.title, this.musicUrl));
    }
}
