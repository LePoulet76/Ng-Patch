package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EdoraBossOverlayDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EdoraBossOverlayDataPacket this$0;

    EdoraBossOverlayDataPacket$1(EdoraBossOverlayDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
