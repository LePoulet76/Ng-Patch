package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionListDataPacket$1 extends TypeToken<ArrayList<HashMap<String, String>>>
{
    final FactionListDataPacket this$0;

    FactionListDataPacket$1(FactionListDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
