package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class EnterpriseContractDataPacket$1 extends TypeToken<ArrayList<HashMap<String, Object>>>
{
    final EnterpriseContractDataPacket this$0;

    EnterpriseContractDataPacket$1(EnterpriseContractDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
