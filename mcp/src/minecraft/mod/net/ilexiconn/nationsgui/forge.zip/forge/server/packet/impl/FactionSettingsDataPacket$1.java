package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionSettingsDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionSettingsDataPacket this$0;

    FactionSettingsDataPacket$1(FactionSettingsDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
