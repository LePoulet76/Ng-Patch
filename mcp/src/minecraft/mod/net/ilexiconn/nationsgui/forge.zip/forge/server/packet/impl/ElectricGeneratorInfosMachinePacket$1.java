package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;

class ElectricGeneratorInfosMachinePacket$1 extends TypeToken<ArrayList<String>>
{
    final ElectricGeneratorInfosMachinePacket this$0;

    ElectricGeneratorInfosMachinePacket$1(ElectricGeneratorInfosMachinePacket this$0)
    {
        this.this$0 = this$0;
    }
}
