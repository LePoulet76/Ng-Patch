package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionSaveFlagDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionSaveFlagDataPacket this$0;

    FactionSaveFlagDataPacket$1(FactionSaveFlagDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
