package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.List;

class GetGroupAndPrimeOthersPacket$2 extends TypeToken<List<String>>
{
    final GetGroupAndPrimeOthersPacket this$0;

    GetGroupAndPrimeOthersPacket$2(GetGroupAndPrimeOthersPacket this$0)
    {
        this.this$0 = this$0;
    }
}
