/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  org.lwjgl.input.Keyboard
 */
package acs.tabbychat;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import acs.tabbychat.PrefsButton;
import acs.tabbychat.TCSetting;
import acs.tabbychat.TCSettingTextBox;
import acs.tabbychat.TabbyChat;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

@SideOnly(value=Side.CLIENT)
public class TCSettingsGUI
extends GuiScreen {
    protected static TabbyChat tc;
    protected static Minecraft mc;
    protected final int margin = 4;
    protected final int line_height = 14;
    public final int displayWidth = 325;
    public final int displayHeight = 180;
    protected int lastOpened = 0;
    protected String name = "";
    protected int bgcolor = 1722148836;
    protected int id = 9000;
    protected static List<TCSettingsGUI> ScreenList;
    public static File tabbyChatDir;
    protected File settingsFile;
    private static final int saveButton = 8901;
    private static final int cancelButton = 8902;

    public TCSettingsGUI() {
        mc = Minecraft.getMinecraft();
        ScreenList.add(this);
    }

    protected TCSettingsGUI(TabbyChat _tc) {
        this();
        tc = _tc;
    }

    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.buttonList.clear();
        int effLeft = (this.width - this.displayWidth) / 2;
        int absLeft = effLeft - this.margin;
        int effTop = (this.height - this.displayHeight) / 2;
        int absTop = effTop - this.margin;
        this.lastOpened = TCSettingsGUI.mc.ingameGUI.getUpdateCounter();
        int effRight = (this.width + this.displayWidth) / 2;
        int bW = 40;
        int bH = this.line_height;
        PrefsButton savePrefs = new PrefsButton(8901, effRight - bW, (this.height + this.displayHeight) / 2 - bH, bW, bH, "Save");
        this.buttonList.add(savePrefs);
        PrefsButton cancelPrefs = new PrefsButton(8902, effRight - 2 * bW - 2, (this.height + this.displayHeight) / 2 - bH, bW, bH, "Cancel");
        this.buttonList.add(cancelPrefs);
        for (int i = 0; i < ScreenList.size(); ++i) {
            TCSettingsGUI.ScreenList.get((int)i).id = 9000 + i;
            if (ScreenList.get(i) == this) continue;
            this.buttonList.add(new PrefsButton(TCSettingsGUI.ScreenList.get((int)i).id, effLeft, effTop + 30 * i, 45, 20, TCSettingsGUI.mc.fontRenderer.trimStringToWidth(TCSettingsGUI.ScreenList.get((int)i).name, 35) + "..."));
            ((PrefsButton)((Object)this.buttonList.get((int)(this.buttonList.size() - 1)))).bgcolor = 0;
        }
    }

    public void mouseClicked(int par1, int par2, int par3) {
        for (int i = 0; i < this.buttonList.size(); ++i) {
            if (!TCSetting.class.isInstance(this.buttonList.get(i))) continue;
            TCSetting tmp = (TCSetting)((Object)this.buttonList.get(i));
            if (tmp.type != "textbox" && tmp.type != "enum" && tmp.type != "slider") continue;
            tmp.mouseClicked(par1, par2, par3);
        }
        super.mouseClicked(par1, par2, par3);
    }

    protected void keyTyped(char par1, int par2) {
        for (int i = 0; i < this.buttonList.size(); ++i) {
            if (!TCSetting.class.isInstance(this.buttonList.get(i))) continue;
            TCSetting tmp = (TCSetting)((Object)this.buttonList.get(i));
            if (tmp.type != "textbox") continue;
            ((TCSettingTextBox)tmp).keyTyped(par1, par2);
        }
        super.keyTyped(par1, par2);
    }

    public void actionPerformed(GuiButton button) {
        if (TCSetting.class.isInstance(button) && ((TCSetting)button).type != "textbox") {
            ((TCSetting)button).actionPerformed();
        } else if (button.id == 8901) {
            for (TCSettingsGUI screen : ScreenList) {
                screen.storeTempVars();
                screen.saveSettingsFile();
            }
            tc.updateDefaults();
            tc.loadPatterns();
            tc.updateFilters();
            mc.displayGuiScreen((GuiScreen)null);
            if (TCSettingsGUI.tc.generalSettings.tabbyChatEnable.getValue().booleanValue()) {
                tc.resetDisplayedChat();
            }
        } else if (button.id == 8902) {
            for (TCSettingsGUI screen : ScreenList) {
                screen.resetTempVars();
            }
            mc.displayGuiScreen((GuiScreen)null);
            if (TCSettingsGUI.tc.generalSettings.tabbyChatEnable.getValue().booleanValue()) {
                tc.resetDisplayedChat();
            }
        } else {
            for (int i = 0; i < ScreenList.size(); ++i) {
                if (button.id != TCSettingsGUI.ScreenList.get((int)i).id) continue;
                mc.displayGuiScreen((GuiScreen)ScreenList.get(i));
            }
        }
        this.validateButtonStates();
    }

    public void validateButtonStates() {
    }

    protected boolean loadSettingsFile() {
        return false;
    }

    protected void saveSettingsFile() {
    }

    protected void storeTempVars() {
    }

    protected void resetTempVars() {
    }

    protected int rowY(int rowNum) {
        return (this.height - this.displayHeight) / 2 + (rowNum - 1) * (this.line_height + this.margin);
    }

    public void drawScreen(int x, int y, float f) {
        int i;
        boolean unicodeStore = TCSettingsGUI.mc.fontRenderer.getUnicodeFlag();
        if (TCSettingsGUI.tc.generalSettings.tabbyChatEnable.getValue().booleanValue() && TCSettingsGUI.tc.advancedSettings.forceUnicode.getValue().booleanValue()) {
            TCSettingsGUI.mc.fontRenderer.setUnicodeFlag(true);
        }
        int iMargin = (this.line_height - TCSettingsGUI.mc.fontRenderer.FONT_HEIGHT) / 2;
        int effLeft = (this.width - this.displayWidth) / 2;
        int absLeft = effLeft - this.margin;
        int effTop = (this.height - this.displayHeight) / 2;
        int absTop = effTop - this.margin;
        TCSettingsGUI.drawRect((int)absLeft, (int)absTop, (int)(absLeft + this.displayWidth + 2 * this.margin), (int)(absTop + this.displayHeight + 2 * this.margin), (int)-2013265920);
        for (i = 0; i < ScreenList.size(); ++i) {
            if (ScreenList.get(i) == this) {
                int delta = TCSettingsGUI.mc.ingameGUI.getUpdateCounter() - this.lastOpened;
                int tabDist = TCSettingsGUI.mc.fontRenderer.getStringWidth(TCSettingsGUI.ScreenList.get((int)i).name) + 2 * this.margin - 40;
                int curWidth = delta <= 5 ? 45 + delta * tabDist / 5 : tabDist + 45;
                TCSettingsGUI.drawRect((int)absLeft, (int)(effTop + 30 * i), (int)(absLeft + curWidth), (int)(effTop + 30 * i + 20), (int)TCSettingsGUI.ScreenList.get((int)i).bgcolor);
                TCSettingsGUI.drawRect((int)(absLeft + 45), (int)absTop, (int)(absLeft + 46), (int)(effTop + 30 * i), (int)0x66FFFFFF);
                TCSettingsGUI.drawRect((int)(absLeft + 45), (int)(effTop + 30 * i + 20), (int)(absLeft + 46), (int)(absTop + this.displayHeight), (int)0x66FFFFFF);
                this.drawString(TCSettingsGUI.mc.fontRenderer, TCSettingsGUI.mc.fontRenderer.trimStringToWidth(TCSettingsGUI.ScreenList.get((int)i).name, curWidth), effLeft, effTop + 6 + 30 * i, 0xFFFFFF);
                continue;
            }
            TCSettingsGUI.drawRect((int)absLeft, (int)(effTop + 30 * i), (int)(absLeft + 45), (int)(effTop + 30 * i + 20), (int)TCSettingsGUI.ScreenList.get((int)i).bgcolor);
        }
        for (i = 0; i < this.buttonList.size(); ++i) {
            ((GuiButton)this.buttonList.get(i)).drawButton(mc, x, y);
        }
        TCSettingsGUI.mc.fontRenderer.setUnicodeFlag(unicodeStore);
    }

    static {
        ScreenList = new ArrayList<TCSettingsGUI>();
        tabbyChatDir = new File("config/ngchat");
    }
}

