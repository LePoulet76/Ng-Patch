package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class EnterpriseParcelleDataPacket$1 extends TypeToken<ArrayList<HashMap<String, Object>>>
{
    final EnterpriseParcelleDataPacket this$0;

    EnterpriseParcelleDataPacket$1(EnterpriseParcelleDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
