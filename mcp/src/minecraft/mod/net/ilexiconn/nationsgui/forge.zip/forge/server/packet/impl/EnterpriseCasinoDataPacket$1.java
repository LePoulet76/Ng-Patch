package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseCasinoDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseCasinoDataPacket this$0;

    EnterpriseCasinoDataPacket$1(EnterpriseCasinoDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
