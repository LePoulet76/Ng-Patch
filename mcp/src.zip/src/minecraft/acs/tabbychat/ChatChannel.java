package acs.tabbychat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.util.StatCollector;
import java.util.ArrayList;
import java.util.List;

public class ChatChannel {
    public ChatButton tab;
    public String title;
    public boolean active = false;

    public ChatChannel(String title) {
        this.title = title;
        Minecraft mc = Minecraft.getMinecraft();
        int width = mc.fontRenderer.getStringWidth("<" + title + ">") + 8;
        this.tab = new ChatButton(9999, 3, 3, width, 14, title);
        this.tab.channel = this;
    }

    public boolean equals(GuiButton btnObj) {
        return this.tab.id == btnObj.id;
    }

    public int getButtonEnd() {
        return this.tab.xPosition + this.tab.getButtonWidth();
    }

    public String getDisplayTitle() {
        return StatCollector.translateToLocal("chat.tab." + this.title.toLowerCase().replace(" ", "_"));
    }

    public void setButtonLoc(int x, int y) {
        this.tab.xPosition = x;
        this.tab.yPosition = y;
    }

    public void unreadNotify(net.minecraft.client.gui.Gui gui, int y, int opacity) {
        Minecraft mc = Minecraft.getMinecraft();
       int tabWidth = mc.fontRenderer.getStringWidth("<" + this.title + ">") + 8;
        int tabHeight = 14; // valeur arbitraire par défaut
        GuiNewChat.drawRect(this.tab.xPosition, y - tabHeight, this.tab.xPosition + tabWidth, y, 0x720000 + (opacity / 2 << 24));

        String str = this.getDisplayTitle();
        int strWidth = mc.fontRenderer.getStringWidth(str);
        int centeredX = this.tab.xPosition + (tabWidth - strWidth) / 2;
        int centeredY = y - (tabHeight + 8) / 2;

        mc.fontRenderer.drawStringWithShadow(str, centeredX, centeredY, 0xFF0000 + (opacity << 24));


    }
    // Champs ajoutés
    public List<ChatLine> chatLog = new ArrayList<ChatLine>();
    public boolean hasSpam = false;
    public int spamCount = 1;
    public boolean unread = false;

    // Méthodes utilitaires
    public void trimLog() {
        int maxLines = 100;
        while (chatLog.size() > maxLines) {
            chatLog.remove(chatLog.size() - 1);
        }
    }

    public int getID() {
        return this.tab.id;
    }

    public void setButtonObj(ChatButton button) {
        this.tab = button;
        this.tab.channel = this;
    }
}
