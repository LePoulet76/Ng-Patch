package net.ilexiconn.nationsgui.forge.server.block.entity;

import net.minecraft.nbt.NBTTagCompound;

/**
 * Stub serveur pour RadioBlockEntity, sans logique client.
 */
public class RadioBlockEntity extends BlockEntity {
    @Override
    public void saveNBTData(NBTTagCompound compound) {}

    @Override
    public void loadNBTData(NBTTagCompound compound) {}
}
