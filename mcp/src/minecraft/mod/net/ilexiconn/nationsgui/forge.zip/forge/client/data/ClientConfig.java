package net.ilexiconn.nationsgui.forge.client.data;

import java.util.ArrayList;
import java.util.List;

public class ClientConfig
{
    public boolean specialEnabled = false;
    public boolean blockInfoEnabled = false;
    public boolean displayPictureFrame = true;
    public boolean displayObjectives = true;
    public boolean vanillaLifeDisplay = false;
    public boolean damageIndicator = true;
    public boolean displayArmorInInfo = true;
    public boolean displayNotifications = true;
    public boolean enableUnicode = false;
    public boolean enableTimestamp = false;
    public boolean enableTag = true;
    public Long currentServerTime = Long.valueOf(0L);
    public boolean TPToTutorial = true;
    public Long lastBonusStartTime = Long.valueOf(0L);
    public boolean FirstSetupClient = true;
    public boolean render3DSkins = true;
    public boolean renderFurnitures = true;
    public boolean renderCustomArmors = true;
    public boolean renderEmotes = true;
    public boolean modelAnimations = true;
    public String trustedMultiServers = "";
    public String directConnectMultiAdress = "";
    public String selectedLang = "";
    public boolean enableChatAnimation = true;
    public boolean enableChatBackground = true;
    public boolean azimutBottom = true;
    public boolean enableAzimut = true;
    public boolean armorInfosRight = true;
    public List<String> openedHelp = new ArrayList();
}
