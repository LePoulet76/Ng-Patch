package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;

class EnterprisePetrolDataPacket$2 extends TypeToken<LinkedHashMap<Date, Double>>
{
    final EnterprisePetrolDataPacket this$0;

    EnterprisePetrolDataPacket$2(EnterprisePetrolDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
