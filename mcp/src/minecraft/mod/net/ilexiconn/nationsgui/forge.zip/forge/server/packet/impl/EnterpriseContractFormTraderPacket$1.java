package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseContractFormTraderPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseContractFormTraderPacket this$0;

    EnterpriseContractFormTraderPacket$1(EnterpriseContractFormTraderPacket this$0)
    {
        this.this$0 = this$0;
    }
}
