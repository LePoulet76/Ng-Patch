package net.ilexiconn.nationsgui.forge.server.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * Stub serveur pour ImageHologramBlock, sans logique client.
 */
public class ImageHologramBlock extends Block {
    public ImageHologramBlock() {
        super(Material.rock);
    }
}
