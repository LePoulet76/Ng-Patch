package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class FactionProfilDataPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final FactionProfilDataPacket this$0;

    FactionProfilDataPacket$1(FactionProfilDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
