package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;

class EnterpriseCasinoDataPacket$2 extends TypeToken<LinkedHashMap<Date, Double>>
{
    final EnterpriseCasinoDataPacket this$0;

    EnterpriseCasinoDataPacket$2(EnterpriseCasinoDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
