package net.ilexiconn.nationsgui.forge.server.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * Stub serveur pour PortalBlock, sans logique client.
 */
public class PortalBlock extends Block {
    public PortalBlock() {
        super(Material.rock);
    }
}