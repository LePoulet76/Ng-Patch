package net.minecraft.block;

public enum EnumMobType
{
    everything,
    mobs,
    players;
}
