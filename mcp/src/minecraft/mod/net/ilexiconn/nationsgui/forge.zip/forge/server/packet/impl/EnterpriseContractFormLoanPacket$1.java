package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class EnterpriseContractFormLoanPacket$1 extends TypeToken<HashMap<String, Object>>
{
    final EnterpriseContractFormLoanPacket this$0;

    EnterpriseContractFormLoanPacket$1(EnterpriseContractFormLoanPacket this$0)
    {
        this.this$0 = this$0;
    }
}
