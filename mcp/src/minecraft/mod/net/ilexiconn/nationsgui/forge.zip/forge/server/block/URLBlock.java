package net.ilexiconn.nationsgui.forge.server.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * Stub serveur pour URLBlock, sans logique client.
 */
public class URLBlock extends Block {
    public URLBlock() {
        super(Material.rock);
    }
}
