package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.List;

class EnterpriseCreateDataPacket$2 extends TypeToken<List<String>>
{
    final EnterpriseCreateDataPacket this$0;

    EnterpriseCreateDataPacket$2(EnterpriseCreateDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
