package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;

class FactionDiplomatieWishDataPacket$1 extends TypeToken<HashMap<String, ArrayList<HashMap<String, String>>>>
{
    final FactionDiplomatieWishDataPacket this$0;

    FactionDiplomatieWishDataPacket$1(FactionDiplomatieWishDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
