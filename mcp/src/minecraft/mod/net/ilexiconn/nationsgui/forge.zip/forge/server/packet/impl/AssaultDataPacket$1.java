package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.HashMap;

class AssaultDataPacket$1 extends TypeToken<HashMap<String, String>>
{
    final AssaultDataPacket this$0;

    AssaultDataPacket$1(AssaultDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
