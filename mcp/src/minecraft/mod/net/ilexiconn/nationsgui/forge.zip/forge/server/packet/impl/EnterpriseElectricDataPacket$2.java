package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;

class EnterpriseElectricDataPacket$2 extends TypeToken<LinkedHashMap<Date, Double>>
{
    final EnterpriseElectricDataPacket this$0;

    EnterpriseElectricDataPacket$2(EnterpriseElectricDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
