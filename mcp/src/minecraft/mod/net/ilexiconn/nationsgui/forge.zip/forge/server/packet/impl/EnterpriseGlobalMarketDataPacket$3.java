package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

class EnterpriseGlobalMarketDataPacket$3 extends TypeToken<Map<String, LinkedHashMap<Date, Double>>>
{
    final EnterpriseGlobalMarketDataPacket this$0;

    EnterpriseGlobalMarketDataPacket$3(EnterpriseGlobalMarketDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
