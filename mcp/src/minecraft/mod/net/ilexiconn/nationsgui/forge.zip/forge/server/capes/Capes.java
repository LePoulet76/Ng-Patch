package net.ilexiconn.nationsgui.forge.server.capes;

/**
 * Stub serveur pour Capes, inutilisé et sans dépendances externes.
 */
public class Capes {
    public static void loadCapes() {
        // Stub: rien à charger côté serveur
    }
}
