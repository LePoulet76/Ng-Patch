package net.ilexiconn.nationsgui.forge.server.packet.impl;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.TreeMap;

class FactionWarDataPacket$1 extends TypeToken<ArrayList<TreeMap<String, Object>>>
{
    final FactionWarDataPacket this$0;

    FactionWarDataPacket$1(FactionWarDataPacket this$0)
    {
        this.this$0 = this$0;
    }
}
